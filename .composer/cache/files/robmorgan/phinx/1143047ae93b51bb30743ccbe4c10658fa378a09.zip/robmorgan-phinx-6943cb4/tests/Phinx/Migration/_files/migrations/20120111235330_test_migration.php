<?php

use Phinx\Migration\AbstractMigration;

class TestMigration extends AbstractMigration
{
    /**
     * Migrate Up.
     */
    public function up()
    {
        // do nothing
    }

    /**
     * Migrate Down.
     */
    public function down()
    {
        // do nothing
    }
}
