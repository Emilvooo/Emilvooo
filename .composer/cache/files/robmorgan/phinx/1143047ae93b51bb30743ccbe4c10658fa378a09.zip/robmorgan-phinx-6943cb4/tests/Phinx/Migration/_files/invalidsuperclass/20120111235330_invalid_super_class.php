<?php

class InvalidSuperClass
{
    /**
     * Migrate Up.
     */
    public function up()
    {
        // do nothing
    }

    /**
     * Migrate Down.
     */
    public function down()
    {
        // do nothing
    }
}
