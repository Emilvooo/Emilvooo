<?php
namespace Test\Phinx\Console\Command\TemplateGenerators;

class DoesNotImplementRequiredInterface
{
    
}
