<?php

use Phinx\Migration\AbstractMigration;

class DuplicateMigration extends AbstractMigration
{
    /**
     * Migrate Up.
     */
    public function up()
    {
        // do nothing
    }

    /**
     * Migrate Down.
     */
    public function down()
    {
        // do nothing
    }
}
