
class leading { }

<?php echo $queryClass ?>

class inner { }

<?php echo $defaultLocale ?>

class trailing { }
