<?hh

enum FooEnum: int {
  HERP = 1;
  DERP = 2;
}
