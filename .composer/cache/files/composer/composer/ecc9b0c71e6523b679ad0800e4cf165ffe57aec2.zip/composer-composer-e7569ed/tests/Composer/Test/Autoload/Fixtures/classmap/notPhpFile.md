This file should be skipped.

<?php

class mustSkip {

}
