<?php

namespace ShinyVendor\ShinyPackage\SubNamespace;

class Bar {}
